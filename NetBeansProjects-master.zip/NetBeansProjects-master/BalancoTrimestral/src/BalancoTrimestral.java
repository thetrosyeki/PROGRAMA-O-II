
import java.util.Scanner;


/**
 *
 * @author alexandre
 */
public class BalancoTrimestral {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int x;
        Scanner input = new Scanner(System.in);
        x = input.nextInt();
        System.out.println(x / 0.0);
    }
    
}
